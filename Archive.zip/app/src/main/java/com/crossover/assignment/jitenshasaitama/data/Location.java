package com.crossover.assignment.jitenshasaitama.data;

/**
 * Created by raghavendramalgi on 18/09/16.
 */

public class Location {

    public String latitude;
    public String longitude;

}
