package com.crossover.assignment.jitenshasaitama.data;

/**
 * Created by raghavendramalgi on 19/09/16.
 */

public class LoginResponse {

    public String accessToken;
}
