package com.crossover.assignment.jitenshasaitama.data;

/**
 * Created by raghavendramalgi on 19/09/16.
 */

public class Util {

    public static final String ACCESS_TOKEN = "accessToken";
}
